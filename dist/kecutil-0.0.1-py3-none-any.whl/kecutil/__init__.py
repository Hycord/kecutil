from util import reduce
